Generalized wrapping with applications to mongo decoration
Put more info here later